import os
import pandas as pd
from flask import Flask, request, render_template, send_file, redirect, url_for, flash
from werkzeug.utils import secure_filename
from jinja2 import Environment, FileSystemLoader
from weasyprint import HTML
from zipfile import ZipFile
from flask_mail import Mail, Message

UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'payslips'
ALLOWED_EXTENSIONS = {'xlsx'}

app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def format_number(value):
    try:
        return "{:,.0f}".format(float(value))
    except:
        return value

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/edit-payslip', methods=['GET', 'POST'])
def edit_payslip():
    if request.method == 'POST':
        data = request.form.to_dict()
        for field in ['nssf', 'payee', 'tuico', 'advance']:
            data[field] = float(data.get(field, 0) or 0)

        data['deductions'] = data['nssf'] + data['payee'] + data['tuico'] + data['advance']
        data['logo_path'] = 'file://' + os.path.join(app.root_path, 'static', 'logo.png').replace('\\', '/')

        return render_template("template-manual-preview.html", **data)

    return render_template("edit_payslip.html")

@app.route('/download-pdf', methods=['POST'])
def download_pdf():
    data = request.form.to_dict()
    for field in ['nssf', 'payee', 'tuico', 'advance']:
        data[field] = float(data.get(field, 0) or 0)
    data['deductions'] = data['nssf'] + data['payee'] + data['tuico'] + data['advance']
    data['logo_path'] = 'file://' + os.path.join(app.root_path, 'static', 'logo.png').replace('\\', '/')

    env = Environment(loader=FileSystemLoader("templates"))
    template = env.get_template("template.html")
    html_out = template.render(**data)
    pdf_path = os.path.join(OUTPUT_FOLDER, f"{data['emp_id']}_manual.pdf")
    HTML(string=html_out).write_pdf(pdf_path)

    return send_file(pdf_path, as_attachment=True)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'payroll_file' not in request.files:
        flash('No file part')
        return redirect(request.url)

    file = request.files['payroll_file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        try:
            df = pd.read_excel(filepath, sheet_name="Salary")
        except Exception as e:
            flash(f"Error reading Excel file or 'Salary' sheet not found: {e}")
            return redirect(url_for('index'))

        df.columns = [str(c).strip().upper().replace('\xa0', ' ') for c in df.columns]
        print("COLUMNS:", df.columns.tolist())

        required_cols = ['EMPLOYEE ID', 'NAME']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            flash(f"Missing required columns: {', '.join(missing_cols)}")
            return redirect(url_for('index'))

        env = Environment(loader=FileSystemLoader("templates"))
        template = env.get_template("template.html")

        logo_path = 'file://' + os.path.join(app.root_path, 'static', 'logo.png')

        for f in os.listdir(OUTPUT_FOLDER):
            os.remove(os.path.join(OUTPUT_FOLDER, f))

        for _, row in df.iterrows():
            if pd.isna(row.get('EMPLOYEE ID')) or pd.isna(row.get('NAME')):
                continue

            deductions = (
                row.get('NSSF @10 % EMPLOYEE', 0) +
                row.get('PAYEE', 0) +
                row.get('TUICO @ 2%', 0) +
                row.get('ADVANE + LOAN', 0)
            )

            html_out = template.render(
                name=row['NAME'],
                emp_id=row['EMPLOYEE ID'],
                position=row.get('POSITION', ''),
                pay_period='June 2025',
                salary_earned=format_number(row.get('SALARY - EARNED', 0)),
                extra_pay=format_number(row.get('EXTRA PAY', 0)),
                house_allowance=format_number(row.get('HOUSE ALLOWANCE', 0)),
                food_allowance=format_number(row.get('FOOD ALLOWANCE', 0)),
                transport_allowance=format_number(row.get('TRANSPORT ALLOWANCE', 0)),
                night_allowance=format_number(row.get('NIGHT ALLOWANCE - 5%', 0)),
                gross=format_number(row.get('GROSS SALARY', 0)),
                nssf=format_number(row.get('NSSF @10 % EMPLOYEE', 0)),
                payee=format_number(row.get('PAYEE', 0)),
                tuico=format_number(row.get('TUICO @ 2%', 0)),
                advance=format_number(row.get('ADVANE + LOAN', 0)),
                deductions=format_number(deductions),
                net=format_number(row.get('NET SALARY', 0)),
                rounded=format_number(row.get('NET SALARY ROUND OFF', 0)),
                logo_path=logo_path
            )

            pdf_path = os.path.join(OUTPUT_FOLDER, f"{row['EMPLOYEE ID']}.pdf")
            HTML(string=html_out).write_pdf(pdf_path)

        zip_path = 'payslips.zip'
        with ZipFile(zip_path, 'w') as zipf:
            for pdf_file in os.listdir(OUTPUT_FOLDER):
                zipf.write(os.path.join(OUTPUT_FOLDER, pdf_file), pdf_file)

        return send_file(zip_path, as_attachment=True)

    flash('Invalid file format. Upload .xlsx only.')
    return redirect(url_for('index'))

app.config.update(
    MAIL_SERVER='smtp.example.com',
    MAIL_PORT=587,
    MAIL_USE_TLS=True,
    MAIL_USERNAME='your-email@example.com',
    MAIL_PASSWORD='password',
)
mail = Mail(app)

def send_payslip_email(to_email, pdf_path, emp_name):
    msg = Message("Your Payslip", sender="no-reply@company.com", recipients=[to_email])
    msg.body = f"Hello {emp_name},\n\nPlease find your payslip attached."
    with app.open_resource(pdf_path) as fp:
        msg.attach(f"Payslip_{emp_name}.pdf", "application/pdf", fp.read())
    mail.send(msg)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=7000)
